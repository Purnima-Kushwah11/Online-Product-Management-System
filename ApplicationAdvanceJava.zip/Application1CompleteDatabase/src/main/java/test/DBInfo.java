package test;

public interface DBInfo 
{
	public static final String driver="oracle.jdbc.driver.OracleDriver";
	public static final String dbURL="jdbc:oracle:thin:@localhost:1521:xe";
	public static final String dbUname="SYSTEM";
	public static final String dbPword="PUNAM";
	

}
